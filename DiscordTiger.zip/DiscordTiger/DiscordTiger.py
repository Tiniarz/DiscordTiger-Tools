import os
import sys
import time
import random
import subprocess
from colorama import Fore, Style, init

init(autoreset=True)

PRINT_SPEED = 0.05
MATRIX_DURATION = 20

BASE_PATH = os.path.dirname(os.path.abspath(__file__))
PROGRAMS_DIR = os.path.join(BASE_PATH, "Program")

def matrix_effect(duration):
    chars = "01" 
    end_time = time.time() + duration
    width = os.get_terminal_size().columns
    
    while time.time() < end_time:
        line = "".join(random.choice(chars) if random.random() > 0.90 else " " for _ in range(width))
        print(Fore.GREEN + line)
        time.sleep(PRINT_SPEED)
    os.system('cls' if os.name == 'nt' else 'clear')

def slow_print(text):
    for line in text.splitlines():
        print(line)
        time.sleep(PRINT_SPEED)

def run_program(program_number):
    script_name = f"{program_number}.py"
    script_path = os.path.join(PROGRAMS_DIR, script_name)
    
    if os.path.exists(script_path):
        os.system('cls' if os.name == 'nt' else 'clear')
        try:
            subprocess.run([sys.executable, script_path])
        except Exception as e:
            print(f"{Fore.RED}Error executing {script_name}: {e}")
            time.sleep(2)
    else:
        print(f"{Fore.RED}\n[!] Error: {script_path} not found.")
        print(f"{Fore.YELLOW}Looked in: {PROGRAMS_DIR}")
        time.sleep(3)

ASCII_ART = f"""{Fore.RED}
 ▓█████▄  ██▓  ██████  ▄████▄    ▒█████    ██▀███  ▓█████▄    ▄▄▄█████▓ ██▓  ▄████ ▓█████  ██▀███  
 ▒██▀ ██▌▓██▒▒██    ▒ ▒██▀ ▀█   ▒██▒  ██▒▓██ ▒ ██▒▒██▀ ██▌   ▓  ██▒ ▓▒▓██▒ ██▒ ▀█▒▓█    ▀ ▓██ ▒ ██▒
 ░██   █▌▒██▒░ ▓██▄   ▒▓█    ▄  ▒██░  ██▒▓██ ░▄█ ▒░██   █▌   ▒ ▓██░ ▒░▒██▒▒██░▄▄▄░▒███    ▓██ ░▄█ ▒
 ░▓█▄   ▌░██░  ▒   ██▒▒▓▓▄ ▄██▒▒██   ██░▒██▀▀█▄  ░▓█▄   ▌   ░ ▓██▓ ░ ░██░░▓█  ██▓▒▓█  ▄ ▒██▀▀█▄  
 ░▒████▓ ░██░▒██████▒▒▒ ▓███▀ ░░ ████▓▒░░██▓ ▒██▒░▒████▓      ▒██▒ ░ ░██░░▒▓███▀▒░▒████▒░██▓ ▒██▒
  ▒▒▓  ▒ ░▓  ▒ ▒▓▒ ▒ ░░ ░▒ ▒  ░░ ▒░▒░▒░ ░ ▒▓ ░▒▓░ ▒▒▓  ▒      ▒ ░░    ░▓    ░▒   ▒ ░░ ▒░ ░░ ▒▓ ░▒▓░
  ░ ▒  ▒  ▒ ░░ ░▒  ░ ░  ░  ▒      ░ ▒ ▒░   ░▒ ░ ▒░ ░ ▒  ▒        ░     ▒ ░  ░    ░  ░ ░  ░  ░▒ ░ ▒░
  ░ ░  ░  ▒ ░░  ░  ░  ░         ░ ░ ░ ▒    ░░   ░  ░ ░  ░      ░       ▒ ░░ ░    ░   ░      ░░   ░  
    ░     ░        ░  ░ ░           ░ ░     ░        ░                  ░        ░   ░  ░   ░      
  ░                   ░                                ░                                         
"""

MENU_BODY = f"""{Fore.RED}
  ────────────────────────────────────────────[ {Fore.WHITE}Discord{Fore.RED} ]─────────────────────────────────────┘
  │                                     │                                     │
  │  [01] Discord Token Nuker           │  [11] Discord Token Mass Dm         │  [21] Discord Nitro Generator
  │  [02] Discord Token Info            │  [12] Discord Token Delete Dm       │  [22] Discord Webhook Info
  │  [03] Discord Token Joiner          │  [13] Discord Token Status Changer  │  [23] Discord Webhook Delete
  │  [04] Discord Token Leaver          │  [14] Discord Token Language Changer│  [24] Discord Webhook Spammer
  │  [05] Discord Token Login           │  [15] Discord Token House Changer   │  [25] Discord Webhook Generator
  │  [06] Discord Token To Id And Brute │  [16] Discord Token Theme Changer   │
  │  [07] Discord Token Server Raid     │  [17] Discord Token Generator       │
  │  [08] Discord Token Spammer         │  [18] Discord Bot Server Nuker      │
  │  [09] Discord Token Delete Friends  │  [19] Discord Bot Invite To Id      │
  │  [10] Discord Token Block Friends   │  [20] Discord Server Info           │
  └─────────────────────────────────────┴─────────────────────────────────────┘
 {Fore.RED}──({Fore.WHITE}disc@discordtiger{Fore.RED})─[{Fore.WHITE}~/Windows/Menu-3{Fore.RED}]
 {Fore.WHITE}└─$ """

def main():
    matrix_effect(MATRIX_DURATION)
    
    slow_print(ASCII_ART)
    slow_print(MENU_BODY)
    
    while True:
        choice = input().strip()
        
        if choice.isdigit():
            formatted_choice = choice.zfill(2)
            run_program(formatted_choice)
            
            os.system('cls' if os.name == 'nt' else 'clear')
            print(ASCII_ART)
            print(MENU_BODY)
        else:
            print(f"{Fore.RED}Invalid Choice.{Fore.WHITE} └─$ ", end="")

if __name__ == "__main__":
    main()